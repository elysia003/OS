#define _CRT_SECURE_NO_DEPRECATE
#include<iostream>
#include"FIFO.h"
#include"LFU.h"
#include"LRU.h"
#include"Quick_LRU.h"
#include"Clock.h"
using namespace std;
